/* This is a generated file, edit the .stub.php file instead.
 * Stub hash: 5b470b70865301d1b7202e78438e4c5686f2a2f1 */


ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_yaoling_encrypt_plus, 0, 0, IS_VOID, 0)
ZEND_END_ARG_INFO()


ZEND_FUNCTION(yaoling_encrypt_plus);


static const zend_function_entry ext_functions[] = {
	ZEND_FE(yaoling_encrypt_plus, arginfo_yaoling_encrypt_plus)
	ZEND_FE_END
};
