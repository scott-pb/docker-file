/* yaoling_encrypt_plus extension for PHP */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

extern "C"
{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "php.h"
#include "ext/standard/info.h"
#include "php_yaoling_encrypt_plus.h"
#include "yaoling_encrypt_plus_arginfo.h"
};
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>
#include <string.h>
#include <fstream>
#include "yaoling_encrypt_plus_cache.h"

#define YAOLING_ENCRYPT "yaoling_encrypt"

using namespace std;

inline bool is_encrypted(unsigned char *class_data)
{
    return (class_data[0] == 0x9b && class_data[1] == 0x97 && class_data[2] == 0x88 && class_data[3] == 0xca && class_data[4] == 0x88);
}

/**
 * @param ch
 * @return
 */
inline unsigned char decrypt_ch(unsigned char ch)
{
    ch ^= 88;
    unsigned char ch_one = ch & 0b11000000;
    unsigned char ch_two = ch & 0b00110000;
    unsigned char ch_three = ch & 0b00001100;
    unsigned char ch_four = ch & 0b00000011;

    unsigned char new_ch_one = ch_two << 2;
    unsigned char new_ch_two = ch_one >> 2;
    unsigned char new_ch_three = ch_four << 2;
    unsigned char new_ch_four = ch_three >> 2;

    unsigned char decrypt_ch = new_ch_one | new_ch_two | new_ch_three | new_ch_four;
    return decrypt_ch;
}

// zend compile
static zend_op_array *(*orig_compile_file)(zend_file_handle *file_handle, int type);

zend_op_array *success(zend_file_handle *file_handle, int type, std::string realbuf, size_t reallen)
{

    if (file_handle->type == ZEND_HANDLE_FP)
        fclose(file_handle->handle.fp);
#ifdef ZEND_HANDLE_FD
    if (file_handle->type == ZEND_HANDLE_FD)
        close(file_handle->handle.fd);
#endif
    file_handle->type = ZEND_HANDLE_FP;

    FILE *fp = tmpfile();

    fwrite(realbuf.c_str(), 1, reallen, fp);

    realbuf.clear();

    rewind(fp);

    file_handle->handle.fp = fp;

    return orig_compile_file(file_handle, type);
}

zend_op_array *yaoling_compile_plus_file(zend_file_handle *file_handle, int type)
{

    std::fstream inputFile;

    struct stat sb;
    stat(file_handle->filename->val, &sb);

    yaoling_encrypt_plus_cache_element *cache_element = get_cache_element(file_handle->filename->val, sb.st_mtime);
    if (cache_element != nullptr)
    {
        return success(file_handle, type, cache_element->m_body, cache_element->m_body_size);
    }

    // open file
    inputFile.open(file_handle->filename->val, ios::in);
    if (!inputFile)
    {
        return orig_compile_file(file_handle, type);
    }

    // body
    inputFile.seekg(0, ios::end);
    int length = inputFile.tellg();
    inputFile.seekg(0, ios::beg);
    unsigned char *data = new unsigned char[length];
    std::string body;
    inputFile.read((char *)data, length);

    //是否加密
    if (!is_encrypted(data))
    {
        inputFile.close();
        delete[] data;
        return orig_compile_file(file_handle, type);
    }

    //解密
    for (int i = 0; i < length; i++)
    {
        body += decrypt_ch(data[i]);
    }

    delete[] data;
    inputFile.close();

    add_cache(file_handle->filename->val, body.c_str(), length, sb.st_mtime);
    return success(file_handle, type, body.c_str(), length);
}

/* For compatibility with older PHP versions */
#ifndef ZEND_PARSE_PARAMETERS_NONE
#define ZEND_PARSE_PARAMETERS_NONE()  \
    ZEND_PARSE_PARAMETERS_START(0, 0) \
    ZEND_PARSE_PARAMETERS_END()
#endif

/* {{{ void test1() */
PHP_FUNCTION(yaoling_encrypt_plus)
{
    ZEND_PARSE_PARAMETERS_NONE();

    php_printf("The extension %s is loaded and working!\r\n", "php_hello");
}
/* }}} */

/* {{{ PHP_RINIT_FUNCTION */
PHP_RINIT_FUNCTION(yaoling_encrypt_plus)
{
#if defined(ZTS) && defined(COMPILE_DL_YAOLING_ENCRYPT_PLUS)
    ZEND_TSRMLS_CACHE_UPDATE();
#endif

    return SUCCESS;
}
/* }}} */

/* {{{ PHP_MINFO_FUNCTION */
PHP_MINFO_FUNCTION(yaoling_encrypt_plus)
{
    php_info_print_table_start();
    php_info_print_table_header(2, "yaoling_encrypt_plus support", "enabled");
    php_info_print_table_end();
}
/* }}} */

/* {{{ PHP_MINIT_FUNCTION */
PHP_MINIT_FUNCTION(yaoling_encrypt_plus)
{

    orig_compile_file = zend_compile_file;

    zend_compile_file = yaoling_compile_plus_file;

    return SUCCESS;
}
/* }}} */

/* {{{ yaoling_encrypt_plus_module_entry */
zend_module_entry yaoling_encrypt_plus_module_entry = {
    STANDARD_MODULE_HEADER,
    "yaoling_encrypt_plus",           /* Extension name */
    ext_functions,                    /* zend_function_entry */
    PHP_MINIT(yaoling_encrypt_plus),  /* PHP_MINIT - Module initialization */
    NULL,                             /* PHP_MSHUTDOWN - Module shutdown */
    PHP_RINIT(yaoling_encrypt_plus),  /* PHP_RINIT - Request initialization */
    NULL,                             /* PHP_RSHUTDOWN - Request shutdown */
    PHP_MINFO(yaoling_encrypt_plus),  /* PHP_MINFO - Module info */
    PHP_YAOLING_ENCRYPT_PLUS_VERSION, /* Version */
    STANDARD_MODULE_PROPERTIES};
/* }}} */

#ifdef COMPILE_DL_YAOLING_ENCRYPT_PLUS
#ifdef ZTS
ZEND_TSRMLS_CACHE_DEFINE()
#endif
extern "C"
{
    ZEND_GET_MODULE(yaoling_encrypt_plus)
}

#endif
