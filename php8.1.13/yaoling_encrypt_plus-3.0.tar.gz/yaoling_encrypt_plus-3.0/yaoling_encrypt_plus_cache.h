#pragma once

#include <iostream>
#include <map>
#include "php.h"

struct yaoling_encrypt_plus_cache_element;

typedef std::map<std::string, yaoling_encrypt_plus_cache_element *> map_cache;

static map_cache *yaoling_encrypt_plus_cache;

#ifdef __cplusplus
extern "C"
{
#endif
    struct yaoling_encrypt_plus_cache_element
    {
        std::string m_body;
        size_t m_body_size;
        long m_file_stime;
    };
    yaoling_encrypt_plus_cache_element *get_cache_element(const std::string &file_name, long file_stime);

    void add_cache(const std::string &file_name, const std::string &body, size_t body_size, long file_stime);

#ifdef __cplusplus
};
#endif