#include "yaoling_encrypt_plus_cache.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <string.h>
#include <fcntl.h>

yaoling_encrypt_plus_cache_element *get_cache_element(const std::string &file_name, long file_stime)
{
    if (yaoling_encrypt_plus_cache == nullptr)
    {
        return nullptr;
    }

    auto it = yaoling_encrypt_plus_cache->find(file_name);
    if (it == yaoling_encrypt_plus_cache->end())
    {
        return nullptr;
    }
    yaoling_encrypt_plus_cache_element *element = it->second;
    if (element != nullptr)
    {
        if (element->m_file_stime == file_stime)
        {
            return element;
        }
        delete element;
        yaoling_encrypt_plus_cache->erase(file_name);
    }
    return nullptr;
}

void add_cache(const std::string &file_name, const std::string &body, size_t body_size, long file_stime)
{
    yaoling_encrypt_plus_cache_element *element = new yaoling_encrypt_plus_cache_element();
   if (yaoling_encrypt_plus_cache == nullptr)
    {
        yaoling_encrypt_plus_cache = new map_cache;
    }

    element->m_body = body;
    element->m_body_size = body_size;
    element->m_file_stime = file_stime;
    (*yaoling_encrypt_plus_cache)[file_name] = element;
}
