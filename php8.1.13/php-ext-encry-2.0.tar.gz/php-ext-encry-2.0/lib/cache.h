//
// Created by 彭彬 on 2023/2/28.
//

#ifndef _YAOLING_ENCRYPT_LIB_CACHE_H
#define _YAOLING_ENCRYPT_LIB_CACHE_H

#define MAX_COUNT 10240 //最大缓存文件数

typedef struct {
    char *key;
    char *value;
} cache_element;

typedef struct {
    cache_element **cache_elements;
    size_t count;
} cache_map;

int add_cache_element(char *key, char *value);

char *get_cache_element(char *key);

int delete_cache_element(char *key);

int flush_cache();


#endif //ENCRYPT_CACHE_CACHE_H