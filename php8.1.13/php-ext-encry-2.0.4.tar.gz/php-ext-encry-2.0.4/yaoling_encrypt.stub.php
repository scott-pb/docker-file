<?php

/** @generate-class-entries */

function yaoling_encrypt_file(string $source_file): bool
{
}

function yaoling_decrypt_file(string $source_file, string $decrypt_key): bool
{
}
