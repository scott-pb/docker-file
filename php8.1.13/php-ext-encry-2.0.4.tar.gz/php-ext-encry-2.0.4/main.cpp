#include <iostream>
#include <fstream>
#include <sys/stat.h>
#include <dirent.h>
#include <cstring>

using namespace std;

extern bool is_file(string path);

extern bool is_dir(string path);

extern void handle_dir(string path);

extern void encrypt_file(string path);

extern short encrypt_ch(char ch);

extern bool str_end_with(std::string str, std::string suffix);

int main(int argc, char *argv[]) {

    string path = "";
    if (argc == 2) {
        path = argv[1];
    }

    if (is_file(path)) {
        cout << "是文件" << path << endl;
        encrypt_file(path);
        return 0;
    }

    if (is_dir(path)) {
        cout << "是文件夹" << path << endl;
        handle_dir(path);
        return 0;
    }


    if (path.empty()) {
        cout << "请输入文件夹路径或文件" << endl;
        return 0;
    }

    cout << "该路径无效" << path << endl;

    return 0;

}

/**
 * 判断是否为文件
 * @param path
 * @return
 */
bool is_file(std::string path) {
    struct stat buffer;
    return (stat(path.c_str(), &buffer) == 0 && S_ISREG(buffer.st_mode));
}

/**
 * 判断是否为文件夹
 * @param path
 * @return
 */
bool is_dir(std::string path) {
    struct stat buffer;
    return (stat(path.c_str(), &buffer) == 0 && S_ISDIR(buffer.st_mode));
}

/**
 * 文件夹处理
 * @param path
 */
void handle_dir(const std::string path) {
    DIR *dir;
    struct dirent *dirent;

    if ((dir = opendir(path.c_str())) != nullptr) {
        while ((dirent = readdir(dir)) != nullptr) {

            if (dirent->d_type == DT_REG) {
                //加密文件
                encrypt_file(string(path + "/" + dirent->d_name));
            } else if (
                    dirent->d_type == DT_DIR
                    && strcmp(dirent->d_name, ".") != 0
                    && strcmp(dirent->d_name, "..") != 0) {
                //读取子文件夹
                handle_dir(string(path + "/" + dirent->d_name));
            }
        }
    }
}

/**
 * 加密文件
 * @param filePath
 */
void encrypt_file(const std::string filePath) {

    if (!str_end_with(filePath, ".php")) {
        cerr << "不是PHP文件:" << filePath << endl;
        return;
    }

    std::fstream file(filePath, ios::in | ios::out);
    if (!file) {
        cerr << "无法打开文件:" << filePath << endl;
        return;
    }

    char ch;
    std::string str;

    std::string key = "yaoling_encrypt";
    for (int i = 0; i < key.length(); i++) {
        short temp = encrypt_ch(key[i]);

        str.append(to_string(temp));
    }

    while (file.get(ch)) {
        short temp = encrypt_ch(ch);
        str.append(to_string(temp));
    }

    file.close();

    file.open(filePath, ios::out);

    file << str << endl;

    cout << "\033[1;32m" << "加密成功文件：" << filePath << "" << "\033[1;32m" << endl;

    file.close();
}

/**
 * 加密char
 * @param ch
 * @return
 */
short encrypt_ch(char ch)   {
    short temp = (short) ch;

    temp <<= 4;

    temp |= 0x8000;

    // 获取当前时间戳
    time_t timestamp = time(nullptr);
    // 使用时间戳设置rand()的种子
    srand(timestamp);

    temp += rand() % 16;

    return temp;
}

bool str_end_with(const std::string str, const std::string suffix) {
    if (suffix.length() > str.length()) { return false; }

    return (str.rfind(suffix) == (str.length() - suffix.length()));
}