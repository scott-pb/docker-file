//
// Created by 彭彬 on 2023/2/28.
//

#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "cache.h"

typedef volatile cache_map cache_maps;

static cache_maps *map;

typedef volatile unsigned int lock_status;

static lock_status cache_lock_status = 0;

void yaoling_encrypt_lock()
{
    for (;;)
    {
        __asm__("NOP");
        if (__sync_bool_compare_and_swap(&cache_lock_status, 0, 1))
        {
            break;
        }
    }
}

void yaoling_encrypt_unlock()
{
    for (;;)
    {
        __asm__("NOP");
        if (__sync_bool_compare_and_swap(&cache_lock_status, 1, 0))
        {
            break;
        }
    }
}

int add_cache_element(char *key, const char *value, size_t reallen, long st_mtimespec)
{
    int map_count = 0;
    if (map)
    {
        map_count = map->count;
    }

    bool has_cache_elements = false;
    for (int i = 0; i < map_count; i++)
    {
        if (strcmp(map->cache_elements[i]->key, key) == 0)
        {
            if (map->cache_elements[i]->st_mtimespec == st_mtimespec)
            {
                has_cache_elements = true;
            }
            else
            {
                delete_cache_element(key);
            }
        }
    }

    if (has_cache_elements)
    {
        return 1;
    }

    cache_element *new_element = (cache_element *)calloc(1, sizeof(cache_element));
    // key
    new_element->key = calloc(strlen(key), sizeof(char));
    strcpy(new_element->key, key);

    size_t str_len = strlen(value);
    new_element->value = calloc(reallen, sizeof(char));
    strncpy(new_element->value, value, reallen);
    new_element->str_len = reallen;

    // file st_mtimespec
    new_element->st_mtimespec = st_mtimespec;

    int real_size = map_count + 1;
    if (!map)
    {
        map = calloc(1, sizeof(map));
        map->cache_elements = (cache_element **)calloc(1, sizeof(*new_element));
    }
    else
    {
        map->cache_elements = realloc(map->cache_elements, real_size * sizeof(*new_element));
    }

    map->cache_elements[map_count] = new_element;
    map->count = real_size;
    return 1;
}

cache_element *get_cache_element(char *key, long st_mtimespec)
{

    int map_count = 0;
    if (map)
    {
        map_count = map->count;
    }

    for (int i = 0; i < map_count; i++)
    {
        if (strcmp(map->cache_elements[i]->key, key) == 0)
        {
            if (map->cache_elements[i]->st_mtimespec == st_mtimespec)
            {
                return map->cache_elements[i];
            }
            else
            {
                delete_cache_element(key);
            }
        }
    }

    return NULL;
}

int delete_cache_element(char *key)
{
    int map_count = 0;
    if (map)
    {
        map_count = map->count;
    }

    for (int i = 0; i < map_count; i++)
    {
        if (strcmp(map->cache_elements[i]->key, key) == 0)
        {
            free(map->cache_elements[i]->key);
            free(map->cache_elements[i]->value);

            map->count--;
            for (int j = i; j < map->count; j++)
            {
                map->cache_elements[j] = map->cache_elements[j + 1];
            }
            map->cache_elements = realloc(map->cache_elements, map->count * sizeof(cache_element *));
            break;
        }
    }

    return 0;
}

int flush_cache()
{

    int map_count = 0;
    if (map)
    {
        map_count = map->count;
    }
    for (int i = 0; i < map_count; i++)
    {
        free(map->cache_elements[i]->key);
        free(map->cache_elements[i]->value);
        free(map->cache_elements[i]);
    }
    free(map);

    return 1;
}