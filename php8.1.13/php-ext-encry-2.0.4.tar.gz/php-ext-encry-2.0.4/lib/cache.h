//
// Created by 彭彬 on 2023/2/28.
//

#ifndef _YAOLING_ENCRYPT_LIB_CACHE_H
#define _YAOLING_ENCRYPT_LIB_CACHE_H

typedef struct
{
    char *key;
    char *value;
    size_t str_len;
    long st_mtimespec;
} cache_element;

typedef struct
{
    cache_element **cache_elements;
    int count;
} cache_map;

int add_cache_element(char *key, const char *value, size_t reallen, long file_st_mtime);

cache_element *get_cache_element(char *key, long st_ctimensec);

int delete_cache_element(char *key);

int flush_cache();

void yaoling_encrypt_lock();

void yaoling_encrypt_unlock();

#endif // ENCRYPT_CACHE_CACHE_H