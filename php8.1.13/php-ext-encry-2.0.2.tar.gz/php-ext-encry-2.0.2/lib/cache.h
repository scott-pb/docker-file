//
// Created by 彭彬 on 2023/2/28.
//

#ifndef _YAOLING_ENCRYPT_LIB_CACHE_H
#define _YAOLING_ENCRYPT_LIB_CACHE_H

#define MAX_COUNT  8196 //最大缓存文件数
#include "php.h"
struct KeyValue {
  char* key;
  void* value;
  long file_st_mtime;
  struct KeyValue* next;
};

struct Cache {
  int capacity;
  int size;
  struct KeyValue** items;
};

bool has_cache();

void init_cache(int capacity);

char *get_cache(char *key, long file_st_mtime);

void delete_cache(char *key);

void set_cache( char *key, void *value,long file_st_mtime);

#endif //ENCRYPT_CACHE_CACHE_H