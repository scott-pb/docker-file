//
// Created by 彭彬 on 2023/2/28.
//

#include <stdlib.h>
#include <string.h>
#include "cache.h"

static struct Cache *cache = NULL;

// hash算法
unsigned long hash(char *key)
{
    unsigned long hash = 5381;
    int c;
    while ((c = *key++))
    {
        hash = ((hash << 5) + hash) + c;
    }
    return hash;
}

// 初始化
void init_cache(int capacity)
{
    cache = malloc(sizeof(struct Cache));
    cache->capacity = capacity;
    cache->size = 0;
    cache->items = calloc(capacity, sizeof(struct KeyValue *));
}

// 获取缓存
char *get_cache(char *key, long file_st_mtime)
{
    unsigned long index = hash(key) % cache->capacity;
    struct KeyValue *item = cache->items[index];
    while (item != NULL)
    {
        if (strcmp(item->key, key) == 0)
        {
            // 文件已经发生了改变
            if (item->file_st_mtime == file_st_mtime)
            {
                return item->value;
            }
            else
            {
                delete_cache(item->key);
                return NULL;
            }
        }
        item = item->next;
    }
    return NULL;
}

// 删除
void delete_cache(char *key)
{
    unsigned long index = hash(key) % cache->capacity;
    struct KeyValue *prev = NULL;
    struct KeyValue *item = cache->items[index];
    while (item != NULL)
    {
        if (strcmp(item->key, key) == 0)
        {
            if (prev == NULL)
            {
                cache->items[index] = item->next;
            }
            else
            {
                prev->next = item->next;
            }
            free(item->key);
            free(item);
            cache->size--;
            return;
        }
        prev = item;
        item = item->next;
    }
}

// 设置cache
void set_cache(char *key, void *value, long file_st_mtime)
{
    if (!cache)
    {
        init_cache(8196);
    }
    unsigned long index = hash(key) % cache->capacity;
    struct KeyValue *item = cache->items[index];
    while (item != NULL)
    {
        if (strcmp(item->key, key) == 0)
        {
            item->value = strdup(value);
            return;
        }
        item = item->next;
    }
    struct KeyValue *new_item = malloc(sizeof(struct KeyValue));
    new_item->key = strdup(key);
    new_item->value = strdup(value);
    new_item->file_st_mtime = file_st_mtime;
    new_item->next = cache->items[index];
    cache->items[index] = new_item;
    cache->size++;
}

bool has_cache()
{
    if (cache)
    {
        return true;
    }
    return false;
}