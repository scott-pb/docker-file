//
// Created by 彭彬 on 2023/2/28.
//

#include <stdlib.h>
#include <string.h>
#include "cache.h"

static cache_map *map = NULL;

int add_cache_element(char *key, long file_st_mtime, char *value)
{
    size_t map_count = 0;
    if (map != NULL)
    {
        map_count = map->count;
    }

    if (map_count > MAX_COUNT)
    {
        return 0;
    }
    for (size_t i = 0; i < map_count; i++)
    {
        if (strcmp(map->cache_elements[i]->key, key) == 0)
        {
            if (map->cache_elements[i]->file_st_mtime == file_st_mtime)
            {
                map->cache_elements[i]->value = value;
            }
            else
            {
                delete_cache_element(key);
            }

            return 2;
        }
    }

    cache_element *new_element = (cache_element *)malloc(sizeof(cache_element));
    new_element->key = strdup(key);
    new_element->value = value;
    new_element->file_st_mtime = file_st_mtime;
    size_t real_size = map_count + 1;
    if (map == NULL)
    {
        map = malloc(sizeof(map));
        map->cache_elements = (cache_element **)malloc(sizeof(*new_element));
    }
    else
    {
        map->cache_elements = realloc(map->cache_elements, real_size * sizeof(*new_element));
    }

    map->cache_elements[map_count] = new_element;
    map->count = real_size;
    return 1;
}

char *get_cache_element(char *key, long file_st_mtime)
{
    size_t map_count = 0;
    if (map != NULL)
    {
        map_count = map->count;
    }
    for (size_t i = 0; i < map_count; i++)
    {
        if (strcmp(map->cache_elements[i]->key, key) == 0)
        {
            if (map->cache_elements[i]->file_st_mtime == file_st_mtime)
            {
                return map->cache_elements[i]->value;
            }
            else
            {
                delete_cache_element(key);
                return NULL;
            }
        }
    }
    return NULL;
}

int delete_cache_element(char *key)
{
    size_t map_count = 0;
    if (map != NULL)
    {
        map_count = map->count;
    }
    for (size_t i = 0; i < map_count; i++)
    {
        if (strcmp(map->cache_elements[i]->key, key) == 0)
        {
            free(map->cache_elements[i]->key);

            map->count--;
            map->cache_elements = realloc(map->cache_elements, map->count * sizeof(cache_element *));
            for (int j = i; j < map->count; j++)
            {
                map->cache_elements[j] = map->cache_elements[j + 1];
            }
            return 1;
        }
    }
    return 0;
}

int flush_cache()
{
    size_t map_count = 0;
    if (map != NULL)
    {
        map_count = map->count;
    }
    for (size_t i = 0; i < map_count; i++)
    {
        free(map->cache_elements[i]->key);
        free(map->cache_elements[i]);
    }
    free(map);
    return 1;
}