<?php

/** @generate-class-entries */

function yaoling_encrypt_plus(): void {}
