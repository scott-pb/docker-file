/* yaoling_encrypt_plus extension for PHP */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

extern "C"
{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "php.h"
#include "ext/standard/info.h"
#include "php_yaoling_encrypt_plus.h"
#include "yaoling_encrypt_plus_arginfo.h"
};
#include "php.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>
#include <string.h>
#include <fstream>
#include "yaoling_encrypt_plus_cache.h"

#define YAOLING_ENCRYPT "yaoling_encrypt"

static bool has_set_encrypt_file_path;

/* {{{ PHP_INI_BEGIN */
PHP_INI_BEGIN()
PHP_INI_ENTRY("yaoling.encrypt_path", NULL, PHP_INI_PERDIR, NULL)
PHP_INI_END()
/* }}} */

using namespace std;

inline unsigned char decrypt_ch(unsigned char ch);

inline bool is_encrypted(unsigned char *class_data);

inline void decrypt_file(const std::string file_path)
{
    std::fstream inputFile;
    inputFile.open(file_path.c_str(), ios::in);
    // body
    inputFile.seekg(0, ios::end);
    int length = inputFile.tellg();
    inputFile.seekg(0, ios::beg);
    unsigned char *data = new unsigned char[length];
    std::string body;
    inputFile.read((char *)data, length);

    // 是加密
    if (is_encrypted(data))
    {
        // 解密
        for (int i = 0; i < length; i++)
        {
            body += decrypt_ch(data[i]);
        }

        add_cache(file_path, body.c_str(), length);
    }

    inputFile.close();
    delete[] data;
}

inline void handle_dir(const std::string path)
{
    DIR *dir;
    struct dirent *dirent;
    if ((dir = opendir(path.c_str())) != nullptr)
    {
        while ((dirent = readdir(dir)) != nullptr)
        {

            if (dirent->d_type == DT_REG)
            {
                // 加密文件
                decrypt_file(string(path + "/" + dirent->d_name));
            }
            else if (
                dirent->d_type == DT_DIR && strcmp(dirent->d_name, ".") != 0 && strcmp(dirent->d_name, "..") != 0)
            {
                // 读取子文件夹
                handle_dir(string(path + "/" + dirent->d_name));
            }
        }
    }
}

inline bool is_encrypted(unsigned char *class_data)
{
    return (class_data[0] == 0x9b && class_data[1] == 0x97 && class_data[2] == 0x88 && class_data[3] == 0xca && class_data[4] == 0x88);
}

/**
 * @param ch
 * @return
 */
inline unsigned char decrypt_ch(unsigned char ch)
{
    ch ^= 88;
    unsigned char ch_one = ch & 0b11000000;
    unsigned char ch_two = ch & 0b00110000;
    unsigned char ch_three = ch & 0b00001100;
    unsigned char ch_four = ch & 0b00000011;

    unsigned char new_ch_one = ch_two << 2;
    unsigned char new_ch_two = ch_one >> 2;
    unsigned char new_ch_three = ch_four << 2;
    unsigned char new_ch_four = ch_three >> 2;

    unsigned char decrypt_ch = new_ch_one | new_ch_two | new_ch_three | new_ch_four;
    return decrypt_ch;
}

// zend compile
static zend_op_array *(*orig_compile_file)(zend_file_handle *file_handle, int type);

zend_op_array *success(zend_file_handle *file_handle, int type, std::string realbuf, size_t reallen)
{

    if (file_handle->type == ZEND_HANDLE_FP)
        fclose(file_handle->handle.fp);
#ifdef ZEND_HANDLE_FD
    if (file_handle->type == ZEND_HANDLE_FD)
        close(file_handle->handle.fd);
#endif
    file_handle->type = ZEND_HANDLE_FP;

    FILE *fp = tmpfile();

    fwrite(realbuf.c_str(), 1, reallen, fp);

    realbuf.clear();

    rewind(fp);

    file_handle->handle.fp = fp;

    return orig_compile_file(file_handle, type);
}

zend_op_array *yaoling_compile_plus_file(zend_file_handle *file_handle, int type)
{

    // ini设置了加密路径
    if (has_set_encrypt_file_path)
    {
        yaoling_encrypt_plus_cache_element *cache_element = get_cache_element(file_handle->filename->val);
        if (cache_element != nullptr)
        {
            return success(file_handle, type, cache_element->m_body, cache_element->m_body_size);
        }

        return orig_compile_file(file_handle, type);
    }

    // 没有设置
    std::fstream inputFile;

    yaoling_encrypt_plus_cache_element *cache_element = get_cache_element(file_handle->filename->val);
    if (cache_element != nullptr)
    {
        return success(file_handle, type, cache_element->m_body, cache_element->m_body_size);
    }

    // open file
    inputFile.open(file_handle->filename->val, ios::in);
    if (!inputFile)
    {
        return orig_compile_file(file_handle, type);
    }

    // body
    inputFile.seekg(0, ios::end);
    int length = inputFile.tellg();
    inputFile.seekg(0, ios::beg);
    unsigned char *data = new unsigned char[length];
    std::string body;
    inputFile.read((char *)data, length);

    // 是否加密
    if (!is_encrypted(data))
    {
        inputFile.close();
        delete[] data;
        return orig_compile_file(file_handle, type);
    }

    // 解密
    for (int i = 0; i < length; i++)
    {
        body += decrypt_ch(data[i]);
    }

    delete[] data;
    inputFile.close();

    add_cache(file_handle->filename->val, body.c_str(), length);
    return success(file_handle, type, body.c_str(), length);
}

/* For compatibility with older PHP versions */
#ifndef ZEND_PARSE_PARAMETERS_NONE
#define ZEND_PARSE_PARAMETERS_NONE()  \
    ZEND_PARSE_PARAMETERS_START(0, 0) \
    ZEND_PARSE_PARAMETERS_END()
#endif

/* {{{ void test1() */
PHP_FUNCTION(yaoling_encrypt_plus)
{
    ZEND_PARSE_PARAMETERS_NONE();

    php_printf("The extension %s is loaded and working!\r\n", "php_hello");
}
/* }}} */

/* {{{ PHP_RINIT_FUNCTION */
PHP_RINIT_FUNCTION(yaoling_encrypt_plus)
{
#if defined(ZTS) && defined(COMPILE_DL_YAOLING_ENCRYPT_PLUS)
    ZEND_TSRMLS_CACHE_UPDATE();
#endif

    return SUCCESS;
}
/* }}} */

/* {{{ PHP_MINFO_FUNCTION */
PHP_MINFO_FUNCTION(yaoling_encrypt_plus)
{
    php_info_print_table_start();
    php_info_print_table_header(2, "yaoling_encrypt_plus support", "enabled");
    php_info_print_table_end();
}
/* }}} */

/* {{{ PHP_MINIT_FUNCTION */
PHP_MINIT_FUNCTION(yaoling_encrypt_plus)
{
    REGISTER_INI_ENTRIES();

    char *encrypt_file_path = INI_STR("yaoling.encrypt_path");

    // 初始化时 就解密
    if (encrypt_file_path && encrypt_file_path[0] != '\0')
    {
        has_set_encrypt_file_path = true;
        const char *delimiter = ",";

        char *saveptr;

        char *token = php_strtok_r(encrypt_file_path, delimiter, &saveptr);

        while (token != NULL)
        {
            handle_dir(std::string(token));
            token = php_strtok_r(NULL, delimiter, &saveptr);
        }
    }

    orig_compile_file = zend_compile_file;

    zend_compile_file = yaoling_compile_plus_file;
    
    return SUCCESS;
}
/* }}} */

/* {{{ PHP_MSHUTDOWN_FUNCTION */
PHP_MSHUTDOWN_FUNCTION(yaoling_encrypt_plus)
{
    drop_all_cache();
    return SUCCESS;
}
/* }}} */
/* {{{ yaoling_encrypt_plus_module_entry */
zend_module_entry yaoling_encrypt_plus_module_entry = {
    STANDARD_MODULE_HEADER,
    "yaoling_encrypt_plus",              /* Extension name */
    ext_functions,                       /* zend_function_entry */
    PHP_MINIT(yaoling_encrypt_plus),     /* PHP_MINIT - Module initialization */
    PHP_MSHUTDOWN(yaoling_encrypt_plus), /* PHP_MSHUTDOWN - Module shutdown */
    PHP_RINIT(yaoling_encrypt_plus),     /* PHP_RINIT - Request initialization */
    NULL,                                /* PHP_RSHUTDOWN - Request shutdown */
    PHP_MINFO(yaoling_encrypt_plus),     /* PHP_MINFO - Module info */
    PHP_YAOLING_ENCRYPT_PLUS_VERSION,    /* Version */
    STANDARD_MODULE_PROPERTIES};
/* }}} */

#ifdef COMPILE_DL_YAOLING_ENCRYPT_PLUS
#ifdef ZTS
ZEND_TSRMLS_CACHE_DEFINE()
#endif
extern "C"
{
    ZEND_GET_MODULE(yaoling_encrypt_plus)
}

#endif
