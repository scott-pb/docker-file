#pragma once

#include <iostream>
#include <map>
#include "php.h"

struct yaoling_encrypt_plus_cache_element;

typedef std::map<std::string, yaoling_encrypt_plus_cache_element *> map_cache;

static map_cache *yaoling_encrypt_plus_cache;

#ifdef __cplusplus
extern "C"
{
#endif
    struct yaoling_encrypt_plus_cache_element
    {
        std::string m_body;
        size_t m_body_size;
    };
    yaoling_encrypt_plus_cache_element *get_cache_element(const std::string &file_name);

    void add_cache(const std::string &file_name, const std::string &body, size_t body_size);

    void drop_all_cache();

#ifdef __cplusplus
};
#endif